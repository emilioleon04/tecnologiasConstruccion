
package mal_ejemplo;

public class correo {
    public void enviar(String mensaje) {
        System.out.println("Enviando correo " + mensaje);
    }
}
