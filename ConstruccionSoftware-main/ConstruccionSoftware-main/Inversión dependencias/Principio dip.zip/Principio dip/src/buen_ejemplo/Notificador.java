package buen_ejemplo;

public interface Notificador {
    void enviar(String mensaje);
}
